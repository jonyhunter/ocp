#!/bin/sh
supervisorctl restart shadowsocks
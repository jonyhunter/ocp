#!/bin/sh
supervisorctl stop shadowsocks
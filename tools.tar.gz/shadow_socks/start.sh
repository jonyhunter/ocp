#!/bin/sh
supervisorctl start shadowsocks
#!/bin/sh
nohup ./ngrokd -domain="bidong.site" -httpAddr=":800" -httpsAddr=":4433" -tlsCrt=./device.crt -tlsKey=./device.key -tunnelAddr=":4443" > /dev/null 2>&1 &
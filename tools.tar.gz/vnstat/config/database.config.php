<?php

/**
 * 数据库配置
 */

/** 数据库类型 */
define('__DB_TYPE', 'mysql');

/** 数据库地址 */
define('__DB_HOST', 'localhost');

/** 数据库端口 */
define('__DB_PORT', 3306);

/** 登录用户名 */
define('__DB_USER', 'root');

/** 登录密码 */
define('__DB_PASS', '199022412');

/** 数据库文件名称 */
define('__DB_NAME', 'bidong.site');

/** SQL语句参数分隔符 */
define('__SQL_DECOLLATOR', '?');

?>
<?php

/** 包含数据库配置文件 */
require_once '../config/database.config.php';

/**
 * 数据库工具类
 */
class DatabaseUtils
{
    /** 唯一实例对象 */
    private static $databaseUtils = null;
    
    /** PDO对象 */
    private $pdo = null;
    
    /**
     * 构造函数
     */
    private function __construct()
    {
        $dsn = $this->generateDsn();
        
        try
        {
            $this->pdo = new PDO($dsn, __DB_USER, __DB_PASS);
        }
        catch(PDOException $e)
        {
            trigger_error($e->getMessage(), E_USER_ERROR);
        }
    }
    
    /**
     * 析构函数
     */
    public function __destruct()
    {
        $this->pdo = null;
        self::$databaseUtils = null;
    }
    
    /**
     * 获取DatabaseUtils类唯一实例
     */
    public static function getInstance()
    {
        if(self::$databaseUtils == null)
        {
            self::$databaseUtils = new self();
        }
        
        return self::$databaseUtils;
    }
    
    /**
     * 创建__clone方法,防止对象被克隆
     */
    public function __clone()
    {
        trigger_error('Single instance class could not be clone', E_USER_ERROR);
    }
    
    /**
     * 根据数据库配置文件生成PDO对象的DSN参数
     * 
     * 注: DSN有严格的命名要求,等号两边是不允许有空格,否则创建PDO对象
     *     的时候没有异常但是执行查询的时候会查询失败
     */
    private function generateDsn()
    {
        return __DB_TYPE . ':' . 'host=' . __DB_HOST . ';' . 'port='. __DB_PORT . ';' . 'dbname=' . __DB_NAME;
    }
    
	/**
	 * 执行查询命令(select)
	 * 
	 * @param $colums 要查询的表中的列(索引数组), null则选择所有列. select $colums[0], $colums[1]...
	 * @param $tables 要查询的表名(索引数组), from $tables[0], $tables[1]...
	 * @param $where 带参数(?)的查询条件, where name like ?...
	 * @param $whereParams $where条件的实际参数值(索引数组, 顺序必须与$where参数顺序一致)
	 * @param $groupBy 指定需要分组(group by)的列名(索引数组), group by $groupBy[0], $groupBy[1]...
	 * @param $having 对分组(group by)后的结果进行进一步约束, having age > ?...
	 * @param $havingParams $having条件的实际参数值(索引数组, 顺序必须与$having参数顺序一致)
	 * @param $orderBy 指定查询结果按照哪些列排序(关联数组 key为列名, value为排序方式-ASC升序;DESC降序), order by...
	 * @param $limit 指定获取查询结果的哪些记录, limit 2, 4(从索引为2的记录开始, 取出4条记录)...
	 * 
	 * @return false, 如果查询失败;否则返回查询后的PDOStatement对象 
	 */
    public function qurey($colums, $tables, $where, $whereParams, $groupBy, $having, $havingParams, $orderBy, $limit)
    {
        $sql = 'select ';
    
		if($colums == null)
		{
			$sql .= '* from ';
		}
		else 
		{
			$length = count($colums);
        
			for($i = 0;$i < $length;$i++)
			{
				$sql = $sql . $colums[$i] . ($i == ($length - 1)) ? ' from ' : ',';
			}
		}
		
		$length = count($tables);
		
		for($i = 0;$i < $length;$i++)
		{
			if($i == ($length - 1))
			{
				$sql .= $tables[$i];
			}
			else
			{
				$sql = $sql . $tables[$i] . ',';
			}
		}
		
		// 处理where语句
		if($where != null)
		{
		    $sql .= ' where ';
		    
		    $where = trim($where);
		    $where = explode(__SQL_DECOLLATOR, $where);
		    $length = count($where);
		     
		    // 不含where参数(?)
		    if($length == 1)
		    {
		        $sql .= $where[0];
		    }
		    // 包含where参数(?)
		    else
		    {
		        for($i = 0;$i < $length;$i++)
		        {
		            $len = strlen($where[$i]);
		             
		            if($len > 0)
		            {
		                $sql = $sql . $where[$i] . "'" . $whereParams[$i] . "'";
		            }
		        }
		    }
		}
		
		// 处理having语句
        if($having != null)
		{
		    $having .= ' having ';
		    
		    $having = trim($having);
		    $having = explode(__SQL_DECOLLATOR, $having);
		    $length = count($having);
		     
		    // 不含having参数(?)
		    if($length == 1)
		    {
		        $sql .= $having[0];
		    }
		    // 包含having参数(?)
		    else
		    {
		        for($i = 0;$i < $length;$i++)
		        {
		            $len = strlen($having[$i]);
		             
		            if($len > 0)
		            {
		                $sql = $sql . $having[$i] . "'" . $havingParams[$i] . "'";
		            }
		        }
		    }
		}
		
		// 处理order by语句
		if($orderBy != null)
		{
		    $sql .= ' order by ';
		    
		    foreach($orderBy as $colum => $order)
		    {
		        $sql = $sql . $colum . ' ' . ($order == null ? 'ASC' : 'DESC') . ',';
		    }
		    
		    $sql = rtrim($sql, ',');
		}
		
		// 处理limit语句
		if($limit != null)
		{
		    $sql .= ' limit '. $limit;
		}
		
		try
		{
		    $stmt = $this->pdo->query($sql);
		    
		    return $stmt;
		}
		catch (Exception $e)
		{
		    return false;
		}
    }
    
    /**
     * 执行插入(insert)命令
     * 
     * @param $table 要插入数据的表名
     * @param $columns 要插入记录的列名(索引数组)
     * @param $columnParams $columns对应的实际值(索引数组,必须与$columns对应)
     * 
     * return false, 如果插入失败;否则返回此次操作影响的记录行数
     */
    public function insert($table, $columns, $columnParams)
    {
        $sql = 'insert into ' . $table;
    
        if($columns == null)
        {
            $sql = $sql . ' values(';
        }
        else
        {
            $sql .= '(';
            
            $len = count($columns);
            
            for($i = 0;$i < $len;$i++)
            {
                $sql = $sql . $columns[$i] . ($i == $len - 1 ? ') values(' : ',');
            }
        }
        
        if($columnParams != null)
        {
            $len = count($columnParams);
            
            for($i = 0;$i < $len;$i++)
            {
                $sql = $sql . "'" . $columnParams[$i]. "'" . ($i == $len - 1 ? ')' : ',');
            }
        }
        
        $count = $this->pdo->exec($sql);
        
        return $count;
    }
    
    /**
     * 执行删除(delete)命令
     * 
     * @param $table 要删除的数据所在的表名
     * @param $where 查询条件
     * @param $whereParams $where的实际参数值(索引数组, 必须和$where对应)
     * 
     * return false,如果数据删除失败;否则返回此次操作影响的记录的行数
     */
    public function delete($table, $where, $whereParams)
    {
        $sql = 'delete from ' . $table;
        
        // 处理where语句
        if($where != null)
        {
            $sql .= ' where ';
        
            $where = trim($where);
            $where = explode(__SQL_DECOLLATOR, $where);
            $length = count($where);
             
            // 不含where参数(?)
            if($length == 1)
            {
                $sql .= $where[0];
            }
            // 包含where参数(?)
            else
            {
                for($i = 0;$i < $length;$i++)
                {
                    $len = strlen($where[$i]);
                     
                    if($len > 0)
                    {
                        $sql = $sql . $where[$i] . "'" . $whereParams[$i] . "'";
                    }
                }
            }
        }
        
        $count = $this->pdo->exec($sql);
        
        return $count;
    }
    
    /**
     * 执行更新(update)命令
     * 
     * @param $table 要更新数据的表名
     * @param $columnValue 更新的列名及对应的值(关联数组)
     * @param $where 更新条件
     * @param $whereParams $where实际参数值(索引数组, 必须和$where对应)
     * 
     * @return false, 如果操作失败;否则返回本次操作影响的记录行数
     */
    public function update($table, $columnValue, $where, $whereParams)
    {
        $sql = 'update ' . $table . ' set ';
        
        foreach($columnValue as $column => $value)
        {
            $sql = $sql . $column . '=' . "'" . $value . "',";
        }
        
        $sql = rtrim($sql, ',');
        
        // 处理where语句
        if($where != null)
        {
            $sql .= ' where ';
        
            $where = trim($where);
            $where = explode(__SQL_DECOLLATOR, $where);
            $length = count($where);
             
            // 不含where参数(?)
            if($length == 1)
            {
                $sql .= $where[0];
            }
            // 包含where参数(?)
            else
            {
                for($i = 0;$i < $length;$i++)
                {
                    $len = strlen($where[$i]);
                     
                    if($len > 0)
                    {
                        $sql = $sql . $where[$i] . "'" . $whereParams[$i] . "'";
                    }
                }
            }
        }
        
        $count = $this->pdo->exec($sql);
        
        return $count;
    }
}

?>
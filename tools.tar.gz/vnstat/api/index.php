<?php

$module = $_GET['module'];
$params = $_GET['params'];

if($module != null)
{
    if($params == null)
    {
        header('Location: ' . '../module/' . $module . '.php');
    }
    else
    {
        header('Location: ' . '../module/' . $module . '.php?params=' . $params);
    }
}

exit(0);

?>
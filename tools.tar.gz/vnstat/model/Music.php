<?php

/**
 * 音乐模型
 */
class Music
{
    public $url = null;
    public $style = null;
    public $tag = null;
    public $date = null;
    public $name = null;
    
    public function __construct($json)
    {
        if($json != null)
        {
            $params = json_decode($json, true);
            
            $this->url = (isset($params['url']) ? $params['url'] : null);
            $this->style = (isset($params['style']) ? $params['style'] : null);
            $this->tag = (isset($params['tag']) ? $params['tag'] : null);
            $this->date = (isset($params['date']) ? $params['date'] : null);
            $this->name = (isset($params['name']) ? $params['name'] : null);
        }
    }
}

?>
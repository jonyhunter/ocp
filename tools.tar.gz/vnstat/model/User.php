<?php

/**
 * 用户模型
 */
class User
{
    public $mobile = null;
    public $email = null;
    public $password = null;
    public $name = null;
    
    public function __construct($json)
    {
        $params = json_decode($json, true);
        
        $this->mobile = (isset($params['mobile']) ? $params['mobile'] : null);
        $this->email = (isset($params['email']) ? $params['email'] : null);
        $this->name = (isset($params['name']) ? $params['name'] : null);
        $this->password = $params['password'];
    }
}

?>
<?php

/** 
 * 请求响应模型
 */
class Response
{
    private $success = false;
    private $data = null;
    
    public function __construct($success = false, $data = null)
    {
        $this->success = $success;
        $this->data = $data;
    }
    
    public function getResponseJson()
    {
        $array = array('success' => ($this->success ? 1 : 0), 'data' => $this->data);
        
        return json_encode($array, JSON_UNESCAPED_UNICODE);
    }
    /**
     * @return the $success
     */
    public function getSuccess()
    {
        return $this->success;
    }

    /**
     * @return the $data
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param Ambigous <boolean, string> $success
     */
    public function setSuccess($success)
    {
        $this->success = $success;
    }

    /**
     * @param string $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>壁咚·云代理</title>
<meta name="description" content="<!--[meta_description]-->">
<meta name="keywords" content="<!--[meta_keywords]-->">
<style type="text/css">
#title {
	color: white;
	font-size: 36px;
	font-weight: bold;
}

#intro {
	color: white;
	font-size: 20px;
}

#space {
	padding-top: 14%;
	margin-bottom: 20px;
}

#myfooter {
	text-align: center;
	font-size: 80%;
	color: #ccc;
	display: none;
}

* {
	margin: 0;
	padding: 0;
}

html, body, #wrap {
	height: 100%;
}

body #wrap {
	height: auto;
	min-height: 100%;
}

#main {
	padding-bottom: 60px;
}

#footer {
	text-align: center;
	position: relative;
	margin-top: -60px;
	height: 60px;
	clear: both;
}

.clearfix:after {
	content: ".";
	display: block;
	height: 0;
	clear: both;
	visibility: hidden;
}

.clearfix {
	display: inline-block;
}

* html .clearfix {
	height: 1%;
}

.clearfix {
	display: block;
}
</style>

<?=injectionJS();?>
<script type="text/javascript">
	window.addDomReadyFunc(function() {
		document.getElementById('options').style.display = 'none';
		document.getElementById('input').focus();
	});
	disableOverride();
</script>

<script type="text/javascript">

function trim(str)
{
	return str.replace(/^\s+|\s+$/g, '');
}

function google()
{
	var input = trim(document.getElementById('input').value);
	if(input != null && input != '' && input != '请输入要访问的网址...')
	{
		var url = input;
		var temp = document.createElement("form");
		temp.action = 'includes/process.php?action=update';
		temp.method = "post";
		temp.style.display = "none";
		var opt = document.createElement("textarea");
		opt.name = 'u';
		opt.value = url;
		temp.appendChild(opt);
		document.body.appendChild(temp);
		temp.submit();

		return temp;
	}	
}
</script>

<!-- 寻找该种方式无法调用的原因
<script type="text/javascript" src="../../js/utils.http.js">
</script>
-->

<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport"
	content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>

	<!--search start here-->

	<div id="wrap">
		<div id="main" class="clearfix">
			<div id="content">
				<div class="search">
					<div id="space">
						<span id="title">壁咚·云代理 </span><span id="intro">自由、纯粹、不作恶</span>
					</div>
					<div class="s-bar">
						<form name="search" action="includes/process.php?action=update"
							method="post" onsubmit="return false;">
							<input name="u" id="input" type="text" value="请输入要访问的网址..."
								onfocus="this.value = '';"
								onblur="if (this.value == '') {this.value = '请输入要访问的网址...';}"> <input
								type="submit" value="壁咚一下" onclick="google();" />
						</form>
					</div>
					<div class="fast">
						<label style="padding-right: 30px;"> <input type="button"
							value="Google"
							onclick="javascript:document.getElementById('input').value='www.google.com/ncr';" />
						</label> <label style="padding-right: 30px;"> <input type="button"
							value="Youtube"
							onclick="javascript:document.getElementById('input').value='www.youtube.com';" />
						</label> <label style="padding-right: 30px;"> <input type="button"
							value="Facebook"
							onclick="javascript:document.getElementById('input').value='www.facebook.com';" />
						</label> <label style="padding-right: 0px;"> <input type="button"
							value="Twitter"
							onclick="javascript:document.getElementById('input').value='www.twitter.com';" />
						</label>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
		<div class="mycopyright">
			<input type="button"
				value="Copyright © 2016 &nbsp 壁咚 &nbsp All Rights Reserved &nbsp Powered by Glype" />
		</div>
		
		<div id="myfooter">
			Powered by <a href="http://www.glype.com/">Glype</a>&reg;
		<!--[version]-->
		</div>
	</div>

	<!--search end here-->

</body>
</html>

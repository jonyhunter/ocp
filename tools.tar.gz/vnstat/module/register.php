<?php

require_once '../model/User.php';
require_once '../model/Response.php';
require_once '../utils/DatabaseUtils.php';

$json = $_GET['params'];
$user = new User($json);

$databaseUtils = DatabaseUtils::getInstance();

$result = $databaseUtils->insert('user', array('mobile', 'email', 'password', 'name'), 
    array($user->mobile, $user->email, $user->password, $user->name));

if($result)
{
    $response = new Response(true, $result);
}
else
{
    $response = new Response();
}

echo $response->getResponseJson();

?>
<?php

require_once '../model/User.php';
require_once '../model/Response.php';
require_once '../utils/DatabaseUtils.php';

require_once '../model/Music.php';
require_once '../config/music.config.php';

date_default_timezone_set("PRC");
$date = date("Ymd");

$databaseUtils = DatabaseUtils::getInstance();

$result = $databaseUtils->qurey(null, array('music'), 'date=?', array($date), null, null, null, null, '0,' . __MUSIC_NUM);

$response = new Response();

if($result)
{
    $count = $result->rowCount();
    
    // 今日还未生成音乐列表
    if($count == 0)
    {
        $result = $databaseUtils->qurey(null, array('music'), 'date=?', array(''), null, null, null, null, '0,' . __MUSIC_NUM);
        
        if($result)
        {
            $count = $result->rowCount();
            
            // 音乐库歌曲数目不足
            if($count < __MUSIC_NUM)
            {
                $result = $databaseUtils->update('music', array('date'=>''), null, null);
                $result = $databaseUtils->qurey(null, array('music'), 'date=?', array(''), null, null, null, null, '0,' . __MUSIC_NUM);
            }
        }
    }
    
    if($result)
    {
        $musicList = array();
        foreach ($result as $row)
        {
            $databaseUtils->update('music', array('date'=>$date), 'id=?', array($row['id']));
    
            $music = new Music(null);
            $music->url = $row['url'];
            $music->style = $row['style'];
            $music->tag = $row['tag'];
            $music->name = $row['name'];
    
            array_push($musicList, $music);
        }
    
        $response->setSuccess(true);
        $response->setData($musicList);
    }
}

echo $response->getResponseJson();

?>
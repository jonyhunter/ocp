<?php

require_once '../model/User.php';
require_once '../model/Response.php';
require_once '../utils/DatabaseUtils.php';

$json = $_GET['params'];
$user = new User($json);

$databaseUtils = DatabaseUtils::getInstance();

$result = $databaseUtils->qurey(null, array('user'), ($user->mobile == null ? 'email=?' : 'mobile=?') . 
    ' and password=?', array(($user->mobile == null ? $user->email : $user->mobile), $user->password),
    null, null, null, null, null);

if($result)
{
    $response = new Response(true, $result);
}
else
{
    $response = new Response();
}

echo $response->getResponseJson();

?>